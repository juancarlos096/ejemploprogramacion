package Actividad4;

import java.util.Scanner;

public class Dam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] asignaturas;

		asignaturas = new String[5];
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			System.out.println("Dime la asignatura numero " + i);
			String dam = sc.nextLine();
			if (dam.toUpperCase().equals("Q")) {
				i = 5;
			} else {
				asignaturas[i] = dam;
			}

		}
		System.out.println("Acabaste");
		for (int i = 0; i < asignaturas.length; i++) {
			
			System.out.println(asignaturas[i]);
		}
	}
	}
