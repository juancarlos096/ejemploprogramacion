package actividad5;

public class Texto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String texto = "En un lugar de la mancha";
		System.out.println(texto.toUpperCase());
		System.out.println(texto.replaceAll("a", "i"));
		System.out.println(texto.length());




	}

}
