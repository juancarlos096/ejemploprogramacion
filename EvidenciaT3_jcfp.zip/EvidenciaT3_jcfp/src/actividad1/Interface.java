package actividad1;

public interface Interface {
	public void inventario();
}
