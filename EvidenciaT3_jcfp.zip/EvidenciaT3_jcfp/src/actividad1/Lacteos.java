package actividad1;

import java.util.Date;

public class Lacteos extends Padre implements Interface {

public String nombre;
public float precioUnitario;


public Lacteos(int unidadesenStock, int unidadesenPedido, Date fecha1, String nombre,
float precioUnitario) {
super(unidadesenStock, unidadesenPedido, fecha1);
this.nombre = nombre;
this.precioUnitario = precioUnitario;
}


public String getNombre() {
return nombre;
}

public void setNombre(String nombre) {
this.nombre = nombre;
}

public float getPrecioUnitario() {
return precioUnitario;
}

public void setPrecioUnitario(float precioUnitario) {
this.precioUnitario = precioUnitario;
}

@Override
public String toString() {
return "Lacteos [nombre=" + nombre + ", precioUnitario=" + precioUnitario + ", unidadesenStock="
+ unidadesenStock + ", unidadesenPedido=" + unidadesenPedido + ", fechaCaducidad=" + fechaCaducidad
+ "]";
}


@Override
public void inventario() {
	
	int total = (int) ((unidadesenStock-unidadesenPedido)*precioUnitario);
	System.out.println("El total de "+nombre+" es: "+total+"�");
	
}


public void total() {
	// TODO Auto-generated method stub
	
}



}