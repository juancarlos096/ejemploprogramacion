package actividad1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Ejecucion {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
		Date fecha1 = sdf2.parse("15-03-2021");
		Date fecha2 = sdf2.parse("21-03-2021");
		Date fecha3 = sdf2.parse("20-03-2021");
		
		Lacteos leche = new Lacteos(100, 80, fecha1, "Leche", 9.95f);
		System.out.println(leche);
		
		Lacteos yogur = new Lacteos(150, 95, fecha2, "Yogur", 15.95f);
		System.out.println(yogur);
		
		Lacteos huevos = new Lacteos(100, 75, fecha3, "Huevos", 7.95f);
		System.out.println(huevos);
		
		System.out.println(leche.toString());
		leche.total();
		
		System.out.println(yogur.toString());
		yogur.total();
		
		System.out.println(huevos.toString());
		huevos.total();
	}
	
}