package actividad3;

import actividad3.Colores.Color;

public class Enumerador {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Color azul = Color.azul;
		
		
		System.out.println(" color favorito es: "+ azul.name()
		);
	}

}
	

