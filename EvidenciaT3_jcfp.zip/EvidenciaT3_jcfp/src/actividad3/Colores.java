package actividad3;

public class Colores {
	public enum Color {
		rojo, amarillo, azul, negro
	}
}
