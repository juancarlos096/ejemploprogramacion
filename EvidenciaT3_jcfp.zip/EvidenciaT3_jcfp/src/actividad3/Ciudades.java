package actividad3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Ciudades {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		List<String> lugares = new ArrayList<String>();
		lugares.add("Madrid");
		lugares.add("Sevilla");
		lugares.add("Madrid");
		lugares.add("Valencia");
		
		lugares.add("Cordoba");
		lugares.remove("Valencia");
		
		Iterator<String> it = lugares.iterator();
		while (it.hasNext()) {
			String lugar = it.next();
			System.out.println(lugar);
					
		}
		
		System.out.println("Listado de n�meros:");
	    ArrayList<Integer> numeros = new ArrayList<Integer>();
	    numeros.add(50);
	    numeros.add(40);
	    numeros.add(35);
	    numeros.add(81);
	    
	    for (int i : numeros) {
	      System.out.println(i);
	    }


		
		
		
		
	}

}



